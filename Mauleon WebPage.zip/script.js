// Menu Toggle for Mobile
const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});

// Close menu when a link is clicked
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('active');
  });
});

// Active Menu Highlight
const sections = document.querySelectorAll('.section');
const navItems = document.querySelectorAll('.nav-link');

window.addEventListener('scroll', () => {
  let current = '';
  
  sections.forEach(section => {
    const sectionTop = section.offsetTop;
    const sectionHeight = section.clientHeight;
    if (pageYOffset >= sectionTop - 200) {
      current = section.getAttribute('id');
    }
  });
  
  navItems.forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('href').includes(current)) {
      item.classList.add('active');
    }
  });
});

// ===== VIEW BUTTON FUNCTIONALITY =====
document.querySelectorAll('.view-btn').forEach(button => {
  button.addEventListener('click', function() {
    const imgSrc = this.parentElement.querySelector('img').src;
    
    const popup = document.createElement('div');
    popup.style.position = 'fixed';
    popup.style.top = '0';
    popup.style.left = '0';
    popup.style.width = '100%';
    popup.style.height = '100%';
    popup.style.backgroundColor = 'rgba(0,0,0,0.9)';
    popup.style.display = 'flex';
    popup.style.justifyContent = 'center';
    popup.style.alignItems = 'center';
    popup.style.zIndex = '9999';
    popup.style.opacity = '0';
    popup.style.transition = 'opacity 0.5s ease';
    
    setTimeout(() => {
      popup.style.opacity = '1';
    }, 10);
    
    const popupImg = document.createElement('img');
    popupImg.src = imgSrc;
    popupImg.style.maxWidth = '90%';
    popupImg.style.maxHeight = '90%';
    popupImg.style.borderRadius = '10px';
    popupImg.style.transform = 'scale(0.8)';
    popupImg.style.transition = 'transform 0.5s ease';
    
    setTimeout(() => {
      popupImg.style.transform = 'scale(1)';
    }, 100);
    
    popup.appendChild(popupImg);
    document.body.appendChild(popup);
    
    popup.addEventListener('click', function() {
      popup.style.opacity = '0';
      popupImg.style.transform = 'scale(0.8)';
      setTimeout(() => {
        document.body.removeChild(popup);
      }, 500);
    });
  });
});

// ===== TYPING ANIMATION =====
const textToType = "Welcome to my Portfolio";
const typingElement = document.querySelector('.home-text h2');
let charIndex = 0;

function typeWriter() {
  if (charIndex < textToType.length) {
    typingElement.innerHTML += textToType.charAt(charIndex);
    charIndex++;
    setTimeout(typeWriter, 100);
  }
}

// Start typing when page loads
window.addEventListener('load', () => {
  if (typingElement) {
    typingElement.innerHTML = "";
    setTimeout(typeWriter, 1000);
  }
});

// ===== SCROLL ANIMATION =====
function checkScroll() {
  const sections = document.querySelectorAll('.section');
  
  sections.forEach(section => {
    const sectionTop = section.getBoundingClientRect().top;
    const triggerPoint = window.innerHeight * 0.8;
    
    if (sectionTop < triggerPoint) {
      section.classList.add('active');
    }
  });
  
  // Animate Achievement Cards
  const cards = document.querySelectorAll('.achievement-card');
  cards.forEach((card, index) => {
    const cardTop = card.getBoundingClientRect().top;
    if (cardTop < window.innerHeight * 0.8) {
      setTimeout(() => {
        card.classList.add('show');
      }, index * 200);
    }
  });
}

// Run on load and scroll
window.addEventListener('load', checkScroll);
window.addEventListener('scroll', checkScroll);